package Server;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "AdditionWS")

public class AdditionWS {

@WebMethod(operationName = "Addition")

public double Addition(@WebParam(name = "n1") double n1,
                       @WebParam(name = "n2") double n2,
                       @WebParam(name = "n3") double n3)
{
    return (n1+n2+n3);
}

}