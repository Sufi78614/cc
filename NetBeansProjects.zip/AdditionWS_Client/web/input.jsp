<%@page contentType="text/html" pageEncoding="UTF-8"%>
<html>
<head>
<title>Addition</title>
</head>

<body>

<h1>Addition of Three Numbers</h1>

<form action="output.jsp" method="POST">

Enter First Number :
<input type="text" name="t1"><br><br>

Enter Second Number :
<input type="text" name="t2"><br><br>

Enter Third Number :
<input type="text" name="t3"><br><br>

<input type="submit" value="Addition">

</form>

</body>
</html>
