<%-- 
    Document   : output
    Created on : Mar 9, 2026, 6:08:11 PM
    Author     : hafiz
--%>

<%@page import="server.AdditionWS"%>
<%@page import="server.AdditionWS"%>
<%@page import="server.AdditionWS_Service"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>


<html>
<body>

<%
try {

AdditionWS_Service service = new AdditionWS_Service();
AdditionWS port = service.getAdditionWSPort();

double n1 = Double.parseDouble(request.getParameter("t1"));
double n2 = Double.parseDouble(request.getParameter("t2"));
double n3 = Double.parseDouble(request.getParameter("t3"));

double result = port.addition(n1,n2,n3);

out.println("Addition of THREE Numbers = " + result);

}

catch(Exception ex)
{
out.println("Error: " + ex.getMessage());
}

%>

</body>
</html>