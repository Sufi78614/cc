<%@page import="server.FactorialWS"%>
<%@page import="server.FactorialWS_Service"%>
<%@page import="client.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<html>
<body>

<h2>Factorial Result</h2>

<%
try {

int num = Integer.parseInt(request.getParameter("t1"));

FactorialWS_Service service = new FactorialWS_Service();
FactorialWS port = service.getFactorialWSPort();

int result = port.factorial(num);

out.println("Factorial = " + result);

}

catch(Exception e)
{
out.println("Error: " + e);
}

%>

</body>
</html>