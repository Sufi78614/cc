<%@page contentType="text/html" pageEncoding="UTF-8"%>

<html>
<body>

<h1>Factorial Web Service</h1>

<form action="output.jsp" method="POST">

Enter The Number :
<input type="text" name="t1">

<br><br>

<input type="submit" value="Factorial">

</form>

</body>
</html>