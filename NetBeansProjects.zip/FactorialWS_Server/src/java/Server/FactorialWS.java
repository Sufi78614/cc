package Server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "FactorialWS")

public class FactorialWS {

@WebMethod(operationName = "factorial")

public int factorial(@WebParam(name = "num") int num) {

int f = 1;

for(int i=1;i<=num;i++)
{
    f = f * i;
}

return f;

}

}