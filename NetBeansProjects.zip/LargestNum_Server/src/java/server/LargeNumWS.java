package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "LargeNumWS")

public class LargeNumWS {

@WebMethod(operationName = "findLargest")

public int findLargest(@WebParam(name="num1") int num1,
                       @WebParam(name="num2") int num2)
{
    return (num1 > num2) ? num1 : num2;
}

}