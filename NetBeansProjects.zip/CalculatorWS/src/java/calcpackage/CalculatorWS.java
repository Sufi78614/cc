package calcpackage;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName="CalculatorWS")

public class CalculatorWS {

@WebMethod(operationName="add")
public double add(@WebParam(name="n1") double n1,
                  @WebParam(name="n2") double n2){
return (n1+n2);
}

@WebMethod(operationName="sub")
public double sub(@WebParam(name="n1") double n1,
                  @WebParam(name="n2") double n2){
return (n1-n2);
}

@WebMethod(operationName="mult")
public double mult(@WebParam(name="n1") double n1,
                   @WebParam(name="n2") double n2){
return (n1*n2);
}

@WebMethod(operationName="div")
public double div(@WebParam(name="n1") double n1,
                  @WebParam(name="n2") double n2){
return (n1/n2);
}

}