<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="server.*"%>

<html>
<body>

<h2>Result</h2>

<%

try {

int a = Integer.parseInt(request.getParameter("num1"));
int b = Integer.parseInt(request.getParameter("num2"));

LargeNumWS_Service service = new LargeNumWS_Service();
LargeNumWS port = service.getLargeNumWSPort();

int result = port.findLargest(a,b);

out.println("Number 1 = " + a + "<br>");
out.println("Number 2 = " + b + "<br>");
out.println("Largest Number = " + result);

}

catch(Exception ex)
{
out.println("Error: " + ex.getMessage());
}

%>

</body>
</html>