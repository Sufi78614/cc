<%@page contentType="text/html" pageEncoding="UTF-8"%>

<html>

<head>
<title>Find Largest Number</title>
</head>

<body>

<h1>Enter Two Numbers</h1>

<form action="output.jsp" method="post">

Enter Number 1 :
<input type="text" name="num1"><br><br>

Enter Number 2 :
<input type="text" name="num2"><br><br>

<input type="submit" value="Find Largest">

</form>

</body>
</html>