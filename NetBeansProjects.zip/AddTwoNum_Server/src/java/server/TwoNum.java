package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "TwoNum")

public class TwoNum {

@WebMethod(operationName = "addition")

public double addition(@WebParam(name="n1") double n1,
                       @WebParam(name="n2") double n2)
{
    return (n1*n2);
}

}