<%@page contentType="text/html" pageEncoding="UTF-8"%>

<html>

<head>
<title>Addition of Two Numbers</title>
</head>

<body>

<h1>Add Two Numbers</h1>

<form action="output.jsp" method="POST">

Enter First Number :
<input type="text" name="t1"><br><br>

Enter Second Number :
<input type="text" name="t2"><br><br>

<input type="submit" value="Submit">

</form>

</body>

</html>