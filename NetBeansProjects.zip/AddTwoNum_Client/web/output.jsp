<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="server.*"%>

<html>
<body>

<h2>Result</h2>

<%

try {

double n1 = Double.parseDouble(request.getParameter("t1"));
double n2 = Double.parseDouble(request.getParameter("t2"));

TwoNum_Service service = new TwoNum_Service();
TwoNum port = service.getTwoNumPort();

double result = port.addition(n1,n2);

out.println("Number 1 = " + n1 + "<br>");
out.println("Number 2 = " + n2 + "<br>");
out.println("Addition = " + result);

}
catch(Exception ex)
{
out.println("Error: " + ex);
}

%>

</body>
</html>