<%-- 
    Document   : output
    Created on : Mar 9, 2026, 5:03:09 PM
    Author     : hafiz
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Hello World!</h1>
            <%-- start web service invocation --%><hr/>
    <%
    try {
	calcpackage.CalculatorWS_Service service = new calcpackage.CalculatorWS_Service();
	calcpackage.CalculatorWS port = service.getCalculatorWSPort();
	 // TODO initialize WS operation arguments here
    double n1 = Double.parseDouble(request.getParameter("t1"));
    double n2 = Double.parseDouble(request.getParameter("t2"));
	// TODO process result here
	double result = port.add(n1, n2);
	out.println("Add = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>
    <%-- start web service invocation --%><hr/>
    <%
    try {
	calcpackage.CalculatorWS_Service service = new calcpackage.CalculatorWS_Service();
	calcpackage.CalculatorWS port = service.getCalculatorWSPort();
	 // TODO initialize WS operation arguments here
    double n1 = Double.parseDouble(request.getParameter("t1"));
    double n2 = Double.parseDouble(request.getParameter("t2"));
	// TODO process result here
	double result = port.div(n1, n2);
	out.println("Div = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>
    <%-- start web service invocation --%><hr/>
    <%
    try {
	calcpackage.CalculatorWS_Service service = new calcpackage.CalculatorWS_Service();
	calcpackage.CalculatorWS port = service.getCalculatorWSPort();
	 // TODO initialize WS operation arguments here
    double n1 = Double.parseDouble(request.getParameter("t1"));
    double n2 = Double.parseDouble(request.getParameter("t2"));
	// TODO process result here
	double result = port.mult(n1, n2);
	out.println("Mul = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>
    <%-- start web service invocation --%><hr/>
    <%
    try {
	calcpackage.CalculatorWS_Service service = new calcpackage.CalculatorWS_Service();
	calcpackage.CalculatorWS port = service.getCalculatorWSPort();
	 // TODO initialize WS operation arguments here
    double n1 = Double.parseDouble(request.getParameter("t1"));
    double n2 = Double.parseDouble(request.getParameter("t2"));
	// TODO process result here
	double result = port.sub(n1, n2);
	out.println("Sub = "+result);
    } catch (Exception ex) {
	// TODO handle custom exceptions here
    }
    %>
    <%-- end web service invocation --%><hr/>

    </body>
</html>